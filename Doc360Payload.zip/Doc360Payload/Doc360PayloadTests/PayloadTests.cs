using Doc360Payload;
using Microsoft.Extensions.Hosting;
using System.Text.Json;

namespace Doc360PayloadTests
{
    [TestClass]
    public class PayloadTests
    {
        [TestInitialize]
        public void Initialize()
        {
            HostApplicationBuilder builder = Host.CreateApplicationBuilder();

            _host = builder.Build();
        }

        public IHost _host { get; set; }

        [TestMethod]
        [TestCategory("Serialization")]
        public void Serialize_Payload()
        {
            string file = @"C:\Users\jbalinsk\source\Temp\Doc360Zips\UMR2025059I2310158.json";
            var text = File.ReadAllText(file);
            var payload = JsonSerializer.Deserialize<PayloadRoot>(text);

            Assert.IsTrue(payload.Patient.PAT_SBR_LAST == "MARSHALL");
        }

        [TestMethod]
        [TestCategory("Serialization")]
        public void ToJson_Serialization()
        {
            string file = @"C:\Users\jbalinsk\source\Temp\Doc360Zips\UMR2025059I2310158.json";
            var text = File.ReadAllText(file);
            var payload = JsonSerializer.Deserialize<PayloadRoot>(text);

            payload.Keys.DocumentType = "TEST";
            payload.ServiceLines[0].SVC_DIAG_PTR_1 = "TEST";
            var json = PayloadRoot.ToJson(payload);
        }

        [TestMethod]
        [TestCategory("Serialization")]
        public void FromJson_Deserialization()
        {
            string file = @"C:\Users\jbalinsk\source\Temp\Doc360Zips\UMR2025059I2310158.json";
            var text = File.ReadAllText(file);
            var payload = PayloadRoot.FromJson(text);

            //payload.Keys.DocumentType = "TEST";
            //payload.ServiceLines[0].SVC_DIAG_PTR_1 = "TEST";
            var json = PayloadRoot.ToJson(payload);


            var deserializedPayload = PayloadRoot.FromJson(json);
        }

        [TestMethod]
        [TestCategory("Serialization")]
        public void Exclude_Null_Zeros_Empty()
        {
            string file = "C:\\Users\\jbalinsk\\source\\Temp\\Test-Nulls-Zeros.txt";
            var text = File.ReadAllText(file);

            var deserializedPayload = PayloadRoot.FromJson(text);

            var json = PayloadRoot.ToJson(deserializedPayload, true, true);

            Assert.IsTrue(!string.IsNullOrEmpty(json), "JSON should not be null or empty.");

            deserializedPayload = PayloadRoot.FromJson(json);
        }

        [TestMethod]
        [TestCategory("Serialization")]
        public void Exclude_Empty_Object()
        {
            string file = "C:\\Users\\jbalinsk\\source\\Temp\\Test-EmptyObject.txt";
            var text = File.ReadAllText(file);

            var deserializedPayload = PayloadRoot.FromJson(text);

            var json = PayloadRoot.ToJson(deserializedPayload, true, true);

            Assert.IsTrue(!string.IsNullOrEmpty(json), "JSON should not be null or empty.");

            deserializedPayload = PayloadRoot.FromJson(json);
        }
    }
}
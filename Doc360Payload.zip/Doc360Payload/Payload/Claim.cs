﻿using System.Text.Json.Serialization;

namespace Doc360Payload.Payload
{
    /// <summary>
    /// EDI_CLM_ROUTE
    /// </summary>
    public class Claim
    {
        [JsonIgnore]
        public string CLM_REC_TYPE { get; set; }
        [JsonIgnore]
        public string CLM_BATCH_NUM { get; set; }
        [JsonPropertyName("grp_no")]
        public string CLM_POLICY { get; set; }
        [JsonIgnore]
        public decimal? CLM_GMS_PROD { get; set; }
        [JsonIgnore]
        public decimal? CLM_GMS_CASE { get; set; }
        [JsonIgnore]
        public decimal? CLM_GMS_UNIT { get; set; }
        [JsonIgnore]
        public string CLM_GMS_CERT { get; set; }
        [JsonIgnore]
        public decimal? CLM_GMS_CLMT { get; set; }
        [JsonPropertyName("pat_acct_no")]
        public string CLM_PAT_CONTROL_NUM { get; set; }
        [JsonPropertyName("submit_amt")]
        public decimal? CLM_SUBMIT_AMT { get; set; }
        [JsonIgnore]
        public string CLM_INSUR_TYPE { get; set; }
        [JsonPropertyName("type")]
        public string CLM_TYPE { get; set; }
        [JsonPropertyName("sign_ind")]
        public string CLM_SIGN_IND { get; set; }
        [JsonPropertyName("prov_asgn_ind")]
        public string CLM_PROV_ASSIGN_IND { get; set; }
        [JsonPropertyName("asgn_ben_ind")]
        public string CLM_ASSIGN_BEN_IND { get; set; }
        [JsonPropertyName("sign_src")]
        public string CLM_SIGN_SOURCE { get; set; }
        [JsonPropertyName("emp_rel_ind")]
        public string CLM_EMP_REL_IND { get; set; }
        [JsonIgnore]
        public string CLM_ACCIDENT_IND { get; set; }
        [JsonIgnore]
        public string CLM_RESPONS_IND { get; set; }
        [JsonPropertyName("filing_ind")]
        public string CLM_FILING_IND { get; set; }
        [JsonIgnore]
        public decimal? CLM_SYMPTOM_IND { get; set; }
        [JsonIgnore]
        public string CLM_INCUR_DT_FORM { get; set; }
        [JsonPropertyName("incur_dt")]
        public DateTime? CLM_INCUR_DATE { get; set; }
        [JsonPropertyName("amt_qual")]
        public string CLM_AMT_QUAL { get; set; }
        [JsonPropertyName("amt_paid")]
        public decimal? CLM_AMT_PAID { get; set; }
        [JsonIgnore]
        public decimal? CLM_DIAG_IND { get; set; }
        [JsonIgnore]
        public string CLM_DIAG_TABLE { get; set; }
        [JsonIgnore]
        public string CLM_DIAG_1 { get; set; }
        [JsonIgnore]
        public string CLM_DIAG_2 { get; set; }
        [JsonIgnore]
        public string CLM_DIAG_3 { get; set; }
        [JsonIgnore]
        public string CLM_DIAG_4 { get; set; }
        [JsonIgnore]
        public decimal? CLM_DISC { get; set; }
        [JsonIgnore]
        public decimal? CLM_DRG { get; set; }
        [JsonIgnore]
        public decimal? CLM_SEMI { get; set; }
        [JsonIgnore]
        public string CLM_ORTHO_DT { get; set; }
        [JsonPropertyName("tpa_id")]
        public string CLM_TPA_ID { get; set; }
        [JsonIgnore]
        public decimal? CLM_APPR_AMT { get; set; }
        [JsonIgnore]
        public string CLM_FILLER { get; set; }
        [JsonIgnore]
        public decimal? CLM_TOT_APPR { get; set; }
        [JsonIgnore]
        public string CLM_M4081 { get; set; }
        [JsonIgnore]
        public decimal? CLM_TOT_BENE { get; set; }
        [JsonIgnore]
        public decimal? CLM_TOT_PRV { get; set; }
        [JsonIgnore]
        public decimal? CLM_TOT_DED { get; set; }
        [JsonIgnore]
        public string CLM_RMKS1 { get; set; }
        [JsonIgnore]
        public string CLM_RMKS2 { get; set; }
        [JsonIgnore]
        public string CLM_RMKS3 { get; set; }
        [JsonIgnore]
        public string CLM_RMKS4 { get; set; }
        [JsonIgnore]
        public string CLM_BLOOD_PD { get; set; }
        [JsonIgnore]
        public string CLM_BLOOD_REM { get; set; }
        [JsonPropertyName("fac_cd")]
        public string CLM_FAC_CD { get; set; }
        [JsonPropertyName("frq_tcd")]
        public string CLM_FRQ_TCD { get; set; }
        [JsonPropertyName("st_prd_frm")]
        public string CLM_ST_PRD_FRM { get; set; }
        [JsonPropertyName("st_prd_to")]
        public string CLM_ST_PRD_TO { get; set; }
        [JsonPropertyName("cvd_dys")]
        public string CLM_CVD_DYS { get; set; }
        [JsonPropertyName("non_cvd_dys")]
        public string CLM_NON_CVD_DYS { get; set; }
        [JsonPropertyName("coin_dys")]
        public string CLM_COIN_DYS { get; set; }
        [JsonPropertyName("lftr_dys")]
        public string CLM_LFTR_DYS { get; set; }
        [JsonPropertyName("adm_dt")]
        public DateTime? CLM_ADM_DT { get; set; }
        [JsonPropertyName("adm_hr")]
        public string CLM_ADM_HR { get; set; }
        [JsonPropertyName("adm_type")]
        public string CLM_ADM_TYP { get; set; }
        [JsonPropertyName("ad_sc")]
        public string CLM_ADM_SC { get; set; }
        [JsonPropertyName("dsc_hr")]
        public string CLM_DSC_HR { get; set; }
        [JsonPropertyName("pat_sts")]
        public string CLM_PAT_STS { get; set; }
        [JsonPropertyName("cc1")]
        public string CLM_CC1 { get; set; }
        [JsonPropertyName("cc2")]
        public string CLM_CC2 { get; set; }
        [JsonPropertyName("cc3")]
        public string CLM_CC3 { get; set; }
        [JsonPropertyName("cc4")]
        public string CLM_CC4 { get; set; }
        [JsonPropertyName("cc5")]
        public string CLM_CC5 { get; set; }
        [JsonPropertyName("cc6")]
        public string CLM_CC6 { get; set; }
        [JsonPropertyName("cc7")]
        public string CLM_CC7 { get; set; }
        [JsonPropertyName("oc1")]
        public string CLM_OC1 { get; set; }
        [JsonPropertyName("od1")]
        public DateTime? CLM_OD1 { get; set; }
        [JsonPropertyName("oc2")]
        public string CLM_OC2 { get; set; }
        [JsonPropertyName("od2")]
        public DateTime? CLM_OD2 { get; set; }
        [JsonPropertyName("oc3")]
        public string CLM_OC3 { get; set; }
        [JsonPropertyName("od3")]
        public DateTime? CLM_OD3 { get; set; }
        [JsonPropertyName("oc4")]
        public string CLM_OC4 { get; set; }
        [JsonPropertyName("od4")]
        public DateTime? CLM_OD4 { get; set; }
        [JsonPropertyName("oc5")]
        public string CLM_OC5 { get; set; }
        [JsonPropertyName("od5")]
        public DateTime? CLM_OD5 { get; set; }
        [JsonPropertyName("oc6")]
        public string CLM_OC6 { get; set; }
        [JsonPropertyName("od6")]
        public DateTime? CLM_OD6 { get; set; }
        [JsonPropertyName("oc7")]
        public string CLM_OC7 { get; set; }
        [JsonPropertyName("od7")]
        public DateTime? CLM_OD7 { get; set; }
        [JsonPropertyName("oc8")]
        public string CLM_OC8 { get; set; }
        [JsonPropertyName("od8")]
        public DateTime? CLM_OD8 { get; set; }
        [JsonPropertyName("spn_cd1")]
        public string CLM_SPN_CD1 { get; set; }
        [JsonPropertyName("odt1_frm")]
        public DateTime? CLM_ODT1_FRM { get; set; }
        [JsonPropertyName("odt1_to")]
        public DateTime? CLM_ODT1_TO { get; set; }
        [JsonPropertyName("spn_cd2")]
        public string CLM_SPN_CD2 { get; set; }
        [JsonPropertyName("odt2_frm")]
        public DateTime? CLM_ODT2_FRM { get; set; }
        [JsonPropertyName("odt2_to")]
        public DateTime? CLM_ODT2_TO { get; set; }
        [JsonPropertyName("spn_cd3")]
        public string CLM_SPN_CD3 { get; set; }
        [JsonPropertyName("odt3_frm")]
        public DateTime? CLM_ODT3_FRM { get; set; }
        [JsonPropertyName("odt3_to")]
        public DateTime? CLM_ODT3_TO { get; set; }
        [JsonIgnore]
        public string CLM_INT_NUM { get; set; }
        [JsonPropertyName("vc01")]
        public string CLM_VC1 { get; set; }
        [JsonPropertyName("vc01_amt")]
        public decimal? CLM_VC_AMT1 { get; set; }
        [JsonPropertyName("vc02")]
        public string CLM_VC2 { get; set; }
        [JsonPropertyName("vc02_amt")]
        public decimal? CLM_VC_AMT2 { get; set; }
        [JsonPropertyName("vc03")]
        public string CLM_VC3 { get; set; }
        [JsonPropertyName("vc03_amt")]
        public decimal? CLM_VC_AMT3 { get; set; }
        [JsonPropertyName("vc04")]
        public string CLM_VC4 { get; set; }
        [JsonPropertyName("vc04_amt")]
        public decimal? CLM_VC_AMT4 { get; set; }
        [JsonPropertyName("vc05")]
        public string CLM_VC5 { get; set; }
        [JsonPropertyName("vc05_amt")]
        public decimal? CLM_VC_AMT5 { get; set; }
        [JsonPropertyName("vc06")]
        public string CLM_VC6 { get; set; }
        [JsonPropertyName("vc06_amt")]
        public decimal? CLM_VC_AMT6 { get; set; }
        [JsonPropertyName("vc07")]
        public string CLM_VC7 { get; set; }
        [JsonPropertyName("vc07_amt")]
        public decimal? CLM_VC_AMT7 { get; set; }
        [JsonPropertyName("vc08")]
        public string CLM_VC8 { get; set; }
        [JsonPropertyName("vc08_amt")]
        public decimal? CLM_VC_AMT8 { get; set; }
        [JsonPropertyName("vc09")]
        public string CLM_VC9 { get; set; }
        [JsonPropertyName("vc09_amt")]
        public decimal? CLM_VC_AMT9 { get; set; }
        [JsonPropertyName("vc10")]
        public string CLM_VC10 { get; set; }
        [JsonPropertyName("vc10_amt")]
        public decimal? CLM_VC_AMT10 { get; set; }
        [JsonPropertyName("vc11")]
        public string CLM_VC11 { get; set; }
        [JsonPropertyName("vc11_amt")]
        public decimal? CLM_VC_AMT11 { get; set; }
        [JsonPropertyName("vc12")]
        public string CLM_VC12 { get; set; }
        [JsonPropertyName("vc12_amt")]
        public decimal? CLM_VC_AMT12 { get; set; }
        [JsonPropertyName("cob_nam1")]
        public string CLM_COB_NAM1 { get; set; }
        [JsonPropertyName("cob_nam2")]
        public string CLM_COB_NAM2 { get; set; }
        [JsonPropertyName("sign_ind2")]
        public string CLM_SIGN_IND2 { get; set; }
        [JsonPropertyName("sign_ind3")]
        public string CLM_SIGN_IND3 { get; set; }
        [JsonPropertyName("assign2")]
        public string CLM_ASSIGN_2 { get; set; }
        [JsonPropertyName("assign3")]
        public string CLM_ASSIGN_3 { get; set; }
        [JsonPropertyName("pr_pmt1")]
        public decimal? CLM_PR_PMT1 { get; set; }
        [JsonPropertyName("pr_pmt2")]
        public decimal? CLM_PR_PMT2 { get; set; }
        [JsonPropertyName("pr_pmt3")]
        public decimal? CLM_PR_PMT3 { get; set; }
        [JsonPropertyName("estp_due1")]
        public decimal? CLM_ESTP_DUE1 { get; set; }
        [JsonPropertyName("estp_due2")]
        public decimal? CLM_ESTP_DUE2 { get; set; }
        [JsonPropertyName("estp_due3")]
        public decimal? CLM_ESTP_DUE3 { get; set; }
        [JsonPropertyName("estp_due4")]
        public decimal? CLM_ESTP_DUE4 { get; set; }
        [JsonPropertyName("cob_nl1")]
        public string CLM_COB_NL1 { get; set; }
        [JsonPropertyName("cob_nf1")]
        public string CLM_COB_NF1 { get; set; }
        [JsonPropertyName("cob_nm1")]
        public string CLM_COB_NM1 { get; set; }
        [JsonPropertyName("cob_nl2")]
        public string CLM_COB_NL2 { get; set; }
        [JsonPropertyName("cob_nf2")]
        public string CLM_COB_NF2 { get; set; }
        [JsonPropertyName("cob_nm2")]
        public string CLM_COB_NM2 { get; set; }
        [JsonPropertyName("cob_rel2")]
        public string CLM_COB_REL2 { get; set; }
        [JsonPropertyName("cob_rel3")]
        public string CLM_COB_REL3 { get; set; }
        [JsonPropertyName("cob_id2")]
        public string CLM_COB_ID2 { get; set; }
        [JsonPropertyName("cob_id3")]
        public string CLM_COB_ID3 { get; set; }
        [JsonPropertyName("cob_grp_nm1")]
        public string CLM_COB_GRP_NM1 { get; set; }
        [JsonPropertyName("cob_grp_nm2")]
        public string CLM_COB_GRP_NM2 { get; set; }
        [JsonPropertyName("ref_num1")]
        public string CLM_REF_NUM1 { get; set; }
        [JsonPropertyName("ref_num2")]
        public string CLM_REF_NUM2 { get; set; }
        [JsonPropertyName("ref_num3")]
        public string CLM_REF_NUM3 { get; set; }
        [JsonPropertyName("ref_num4")]
        public string CLM_REF_NUM4 { get; set; }
        [JsonPropertyName("ref_num5")]
        public string CLM_REF_NUM5 { get; set; }
        [JsonIgnore]
        public string CLM_EMP_STS1 { get; set; }
        [JsonIgnore]
        public string CLM_EMP_STS2 { get; set; }
        [JsonPropertyName("orgnm1")]
        public string CLM_COB_ORGNM1 { get; set; }
        [JsonPropertyName("orgnm2")]
        public string CLM_COB_ORGNM2 { get; set; }
        [JsonIgnore]
        public string CLM_COB_ORG_ADR1 { get; set; }
        [JsonIgnore]
        public string CLM_COB_ORG_CITY1 { get; set; }
        [JsonIgnore]
        public string CLM_COB_ORG_ST1 { get; set; }
        [JsonIgnore]
        public string CLM_COB_ORG_ZIP1 { get; set; }
        [JsonIgnore]
        public string CLM_COB_ORG_ADR2 { get; set; }
        [JsonIgnore]
        public string CLM_COB_ORG_CITY2 { get; set; }
        [JsonIgnore]
        public string CLM_COB_ORG_ST2 { get; set; }
        [JsonIgnore]
        public string CLM_COB_ORG_ZIP2 { get; set; }
        [JsonIgnore]
        public string CLM_DIAG_5 { get; set; }
        [JsonIgnore]
        public string CLM_DIAG_6 { get; set; }
        [JsonIgnore]
        public string CLM_DIAG_7 { get; set; }
        [JsonIgnore]
        public string CLM_DIAG_8 { get; set; }
        [JsonIgnore]
        public string CLM_DIAG_9 { get; set; }
        [JsonIgnore]
        public string CLM_DIAG_10 { get; set; }
        [JsonIgnore]
        public string CLM_DIAG_11 { get; set; }
        [JsonIgnore]
        public string CLM_METHOD { get; set; }
        [JsonIgnore]
        public string CLM_PROC_CD1 { get; set; }
        [JsonIgnore]
        public DateTime? CLM_PROC_DT1 { get; set; }
        [JsonIgnore]
        public string CLM_PROC_CD2 { get; set; }
        [JsonIgnore]
        public DateTime? CLM_PROC_DT2 { get; set; }
        [JsonIgnore]
        public string CLM_PROC_CD3 { get; set; }
        [JsonIgnore]
        public DateTime? CLM_PROC_DT3 { get; set; }
        [JsonIgnore]
        public string CLM_PROC_CD4 { get; set; }
        [JsonIgnore]
        public DateTime? CLM_PROC_DT4 { get; set; }
        [JsonIgnore]
        public string CLM_PROC_CD5 { get; set; }
        [JsonIgnore]
        public DateTime? CLM_PROC_DT5 { get; set; }
        [JsonIgnore]
        public string CLM_PROC_CD6 { get; set; }
        [JsonIgnore]
        public DateTime? CLM_PROC_DT6 { get; set; }
        [JsonPropertyName("message")]
        public string CLM_MESSAGE { get; set; }
        [JsonPropertyName("dt")]
        public DateTime? CLM_DATE { get; set; }
        [JsonIgnore]
        public string CLM_FAC_REND_NAME { get; set; }
        [JsonIgnore]
        public string CLM_FAC_REND_ADDR1 { get; set; }
        [JsonIgnore]
        public string CLM_FAC_REND_ADDR2 { get; set; }
        [JsonIgnore]
        public string CLM_FAC_REND_CITY { get; set; }
        [JsonIgnore]
        public string CLM_FAC_REND_ST { get; set; }
        [JsonIgnore]
        public string CLM_FAC_REND_ZIP { get; set; }
        [JsonIgnore]
        public decimal? CLM_TOT_INT { get; set; }
        [JsonIgnore]
        public string CLM_ACCIDENT_ST { get; set; }
        [JsonIgnore]
        public DateTime? CLM_SIMILAR_ILL_DT { get; set; }
        [JsonIgnore]
        public DateTime? CLM_DISABILITY_START_DT { get; set; }
        [JsonIgnore]
        public DateTime? CLM_DISABILITY_END_DT { get; set; }
        [JsonIgnore]
        public DateTime? CLM_HOSP_ADMISSION_DT { get; set; }
        [JsonIgnore]
        public DateTime? CLM_HOSP_DISCHARGE_DT { get; set; }
        [JsonIgnore]
        public string CLM_LAB_NAME { get; set; }
        [JsonIgnore]
        public string CLM_PRIOR_AUTH_NUM { get; set; }
        [JsonIgnore]
        public string CLM_EMER_IND { get; set; }
        [JsonPropertyName("pre_prcd_amt")]
        public decimal? CLM_PRE_PRICED_AMT { get; set; }
        [JsonPropertyName("pre_prcd_sub_id")]
        public string CLM_PRE_PRICED_SUB_ID { get; set; }
        [JsonPropertyName("prov_agmt")]
        public string CLM_PROV_AGMT { get; set; }
        [JsonPropertyName("pre_prcd_ref_no")]
        public string CLM_PRE_PRICED_REF_NO { get; set; }
        [JsonPropertyName("pre_prcd_allw_amt")]
        public decimal? CLM_PRE_PRICED_ALLW_AMT { get; set; }
        [JsonPropertyName("pre_prcd_tpo_id")]
        public string CLM_PRE_PRICED_TPO_ID { get; set; }
        [JsonIgnore]
        public string CLM_DOC_ID_CD { get; set; }
        [JsonIgnore]
        public string CLM_ADJUST_IND { get; set; }
        [JsonIgnore]
        public decimal? CLM_ORIG_APPROV_AMT { get; set; }
        [JsonIgnore]
        public decimal? CLM_ORIG_PAID_AMT { get; set; }
        [JsonIgnore]
        public string CLM_ORIG_PAYOR_CLM_CNTL_NUM { get; set; }
        [JsonIgnore]
        public string CLM_REQ_PREDN_EST_IND { get; set; }
        [JsonIgnore]
        public DateTime? CLM_PLCMT_DATE { get; set; }
        [JsonIgnore]
        public decimal? CLM_TRTMNT_MO_CNT { get; set; }
        [JsonIgnore]
        public string CLM_PLCMT_CD { get; set; }
        [JsonIgnore]
        public string CLM_VEN_NTWK_CD { get; set; }
        [JsonIgnore]
        public string CLM_VEN_NTWK_NAME { get; set; }
        [JsonIgnore]
        public string CLM_REPRICE_IND { get; set; }
        [JsonIgnore]
        public decimal? CLM_MDCR_PCT100 { get; set; }
        [JsonIgnore]
        public decimal? CLM_MDCR_PCT80 { get; set; }
        [JsonIgnore]
        public decimal? CLM_NON_COV_CHRG { get; set; }
        [JsonIgnore]
        public decimal? CLM_CONTR_AMT { get; set; }
        [JsonIgnore]
        public decimal? CLM_CORR_RVRS_AMT { get; set; }
        [JsonIgnore]
        public decimal? CLM_OTH_ADJ_AMT { get; set; }
        [JsonIgnore]
        public decimal? CLM_PAYER_INIT_RDCTN_AMT { get; set; }
        [JsonPropertyName("pt_resp_amt")]
        public decimal? CLM_PTNT_RSPNS_AMT { get; set; }
        [JsonPropertyName("oi_orgn_cd")]
        public string CLM_OI_ORGN_CD { get; set; }
        [JsonPropertyName("pnd_scp_ind")]
        public string CLM_PND_SCP_IND { get; set; }
        [JsonIgnore]
        public string CLM_PND_CSR_IND { get; set; }
        [JsonIgnore]
        public string CLM_ATCH_IND { get; set; }
        [JsonIgnore]
        public string CLM_CLM0501 { get; set; }
        [JsonIgnore]
        public string CLM_CLM0502 { get; set; }
        [JsonIgnore]
        public string CLM_CLM0503 { get; set; }

        [JsonPropertyName("pwk1_1")]
        public string CLM_PWK01_01 { get; set; }
        [JsonPropertyName("pwk2_1")]
        public string CLM_PWK02_01 { get; set; }
        [JsonPropertyName("pwk5_1")]
        public string CLM_PWK05_01 { get; set; }
        [JsonPropertyName("pwk6_1")]
        public string CLM_PWK06_01 { get; set; }
        [JsonPropertyName("pwk7_1")]
        public string CLM_PWK07_01 { get; set; }
        [JsonPropertyName("pwk1_2")]
        public string CLM_PWK01_02 { get; set; }
        [JsonPropertyName("pwk2_2")]
        public string CLM_PWK02_02 { get; set; }
        [JsonPropertyName("pwk5_2")]
        public string CLM_PWK05_02 { get; set; }
        [JsonPropertyName("pwk6_2")]
        public string CLM_PWK06_02 { get; set; }
        [JsonPropertyName("pwk7_2")]
        public string CLM_PWK07_02 { get; set; }
        [JsonPropertyName("pwk1_3")]
        public string CLM_PWK01_03 { get; set; }
        [JsonPropertyName("pwk2_3")]
        public string CLM_PWK02_03 { get; set; }
        [JsonPropertyName("pwk5_3")]
        public string CLM_PWK05_03 { get; set; }
        [JsonPropertyName("pwk6_3")]
        public string CLM_PWK06_03 { get; set; }
        [JsonPropertyName("pwk7_3")]
        public string CLM_PWK07_03 { get; set; }
        [JsonPropertyName("pwk1_4")]
        public string CLM_PWK01_04 { get; set; }
        [JsonPropertyName("pwk2_4")]
        public string CLM_PWK02_04 { get; set; }
        [JsonPropertyName("pwk5_4")]
        public string CLM_PWK05_04 { get; set; }
        [JsonPropertyName("pwk6_4")]
        public string CLM_PWK06_04 { get; set; }
        [JsonPropertyName("pwk7_4")]
        public string CLM_PWK07_04 { get; set; }
        [JsonPropertyName("pwk1_5")]
        public string CLM_PWK01_05 { get; set; }
        [JsonPropertyName("pwk2_5")]
        public string CLM_PWK02_05 { get; set; }
        [JsonPropertyName("pwk5_5")]
        public string CLM_PWK05_05 { get; set; }
        [JsonPropertyName("pwk6_5")]
        public string CLM_PWK06_05 { get; set; }
        [JsonPropertyName("pwk7_5")]
        public string CLM_PWK07_05 { get; set; }
        [JsonPropertyName("pwk1_6")]
        public string CLM_PWK01_06 { get; set; }
        [JsonPropertyName("pwk2_6")]
        public string CLM_PWK02_06 { get; set; }
        [JsonPropertyName("pwk5_6")]
        public string CLM_PWK05_06 { get; set; }
        [JsonPropertyName("pwk6_6")]
        public string CLM_PWK06_06 { get; set; }
        [JsonPropertyName("pwk7_6")]
        public string CLM_PWK07_06 { get; set; }
        [JsonPropertyName("pwk1_7")]
        public string CLM_PWK01_07 { get; set; }
        [JsonPropertyName("pwk2_7")]
        public string CLM_PWK02_07 { get; set; }
        [JsonPropertyName("pwk5_7")]
        public string CLM_PWK05_07 { get; set; }
        [JsonPropertyName("pwk6_7")]
        public string CLM_PWK06_07 { get; set; }
        [JsonPropertyName("pwk7_7")]
        public string CLM_PWK07_07 { get; set; }
        [JsonPropertyName("pwk1_8")]
        public string CLM_PWK01_08 { get; set; }
        [JsonPropertyName("pwk2_8")]
        public string CLM_PWK02_08 { get; set; }
        [JsonPropertyName("pwk5_8")]
        public string CLM_PWK05_08 { get; set; }
        [JsonPropertyName("pwk6_8")]
        public string CLM_PWK06_08 { get; set; }
        [JsonPropertyName("pwk7_8")]
        public string CLM_PWK07_08 { get; set; }
        [JsonPropertyName("pwk1_9")]
        public string CLM_PWK01_09 { get; set; }
        [JsonPropertyName("pwk2_9")]
        public string CLM_PWK02_09 { get; set; }
        [JsonPropertyName("pwk5_9")]
        public string CLM_PWK05_09 { get; set; }
        [JsonPropertyName("pwk6_9")]
        public string CLM_PWK06_09 { get; set; }
        [JsonPropertyName("pwk7_9")]
        public string CLM_PWK07_09 { get; set; }
        [JsonPropertyName("pwk1_10")]
        public string CLM_PWK01_10 { get; set; }
        [JsonPropertyName("pwk2_10")]
        public string CLM_PWK02_10 { get; set; }
        [JsonPropertyName("pwk5_10")]
        public string CLM_PWK05_10 { get; set; }
        [JsonPropertyName("pwk6_10")]
        public string CLM_PWK06_10 { get; set; }
        [JsonPropertyName("pwk7_10")]
        public string CLM_PWK07_10 { get; set; }
        [JsonPropertyName("k3_1")]
        public string CLM_K301_01 { get; set; }
        [JsonPropertyName("k3_2")]
        public string CLM_K301_02 { get; set; }
        [JsonPropertyName("k3_3")]
        public string CLM_K301_03 { get; set; }
        [JsonPropertyName("k3_4")]
        public string CLM_K301_04 { get; set; }
        [JsonPropertyName("k3_5")]
        public string CLM_K301_05 { get; set; }
        [JsonPropertyName("k3_6")]
        public string CLM_K301_06 { get; set; }
        [JsonPropertyName("k3_7")]
        public string CLM_K301_07 { get; set; }
        [JsonPropertyName("k3_8")]
        public string CLM_K301_08 { get; set; }
        [JsonPropertyName("k3_9")]
        public string CLM_K301_09 { get; set; }
        [JsonPropertyName("k3_10")]
        public string CLM_K301_10 { get; set; }
        [JsonPropertyName("nte1_1")]
        public string CLM_NTE01_CLAIM_01 { get; set; }
        [JsonPropertyName("nte2_1")]
        public string CLM_NTE02_CLAIM_01 { get; set; }
        [JsonPropertyName("nte1_2")]
        public string CLM_NTE01_CLAIM_02 { get; set; }
        [JsonPropertyName("nte2_2")]
        public string CLM_NTE02_CLAIM_02 { get; set; }
        [JsonPropertyName("nte1_3")]
        public string CLM_NTE01_CLAIM_03 { get; set; }
        [JsonPropertyName("nte2_3")]
        public string CLM_NTE02_CLAIM_03 { get; set; }
        [JsonPropertyName("nte1_4")]
        public string CLM_NTE01_CLAIM_04 { get; set; }
        [JsonPropertyName("nte2_4")]
        public string CLM_NTE02_CLAIM_04 { get; set; }
        [JsonPropertyName("nte1_5")]
        public string CLM_NTE01_CLAIM_05 { get; set; }
        [JsonPropertyName("nte2_5")]
        public string CLM_NTE02_CLAIM_05 { get; set; }
        [JsonPropertyName("nte1_6")]
        public string CLM_NTE01_CLAIM_06 { get; set; }
        [JsonPropertyName("nte2_6")]
        public string CLM_NTE02_CLAIM_06 { get; set; }
        [JsonPropertyName("nte1_7")]
        public string CLM_NTE01_CLAIM_07 { get; set; }
        [JsonPropertyName("nte2_7")]
        public string CLM_NTE02_CLAIM_07 { get; set; }
        [JsonPropertyName("nte1_8")]
        public string CLM_NTE01_CLAIM_08 { get; set; }
        [JsonPropertyName("nte2_8")]
        public string CLM_NTE02_CLAIM_08 { get; set; }
        [JsonPropertyName("nte1_9")]
        public string CLM_NTE01_CLAIM_09 { get; set; }
        [JsonPropertyName("nte2_9")]
        public string CLM_NTE02_CLAIM_09 { get; set; }
        [JsonPropertyName("nte1_10")]
        public string CLM_NTE01_CLAIM_10 { get; set; }
        [JsonPropertyName("nte2_10")]
        public string CLM_NTE02_CLAIM_10 { get; set; }
        [JsonPropertyName("nte1_blng")]
        public string CLM_NTE01_BLNG { get; set; }
        [JsonPropertyName("nte2_blng")]
        public string CLM_NTE02_BLNG { get; set; }
        [JsonPropertyName("hibf1_1")]
        public string CLM_HIBF01_2_01 { get; set; }
        [JsonPropertyName("hibf2_1")]
        public string CLM_HIBF02_2_01 { get; set; }
        [JsonPropertyName("hibf3_1")]
        public string CLM_HIBF03_2_01 { get; set; }
        [JsonPropertyName("hibf4_1")]
        public string CLM_HIBF04_2_01 { get; set; }
        [JsonPropertyName("hibf5_1")]
        public string CLM_HIBF05_2_01 { get; set; }
        [JsonPropertyName("hibf6_1")]
        public string CLM_HIBF06_2_01 { get; set; }
        [JsonPropertyName("hibf7_1")]
        public string CLM_HIBF07_2_01 { get; set; }
        [JsonPropertyName("hibf8_1")]
        public string CLM_HIBF08_2_01 { get; set; }
        [JsonPropertyName("hibf9_1")]
        public string CLM_HIBF09_2_01 { get; set; }
        [JsonPropertyName("hibf10_1")]
        public string CLM_HIBF10_2_01 { get; set; }
        [JsonPropertyName("hibf11_1")]
        public string CLM_HIBF11_2_01 { get; set; }
        [JsonPropertyName("hibf12_1")]
        public string CLM_HIBF12_2_01 { get; set; }
        [JsonPropertyName("hibf1_2")]
        public string CLM_HIBF01_2_02 { get; set; }
        [JsonPropertyName("hibf2_2")]
        public string CLM_HIBF02_2_02 { get; set; }
        [JsonPropertyName("hibf3_2")]
        public string CLM_HIBF03_2_02 { get; set; }
        [JsonPropertyName("hibf4_2")]
        public string CLM_HIBF04_2_02 { get; set; }
        [JsonPropertyName("hibf5_2")]
        public string CLM_HIBF05_2_02 { get; set; }
        [JsonPropertyName("hibf6_2")]
        public string CLM_HIBF06_2_02 { get; set; }
        [JsonPropertyName("hibf7_2")]
        public string CLM_HIBF07_2_02 { get; set; }
        [JsonPropertyName("hibf8_2")]
        public string CLM_HIBF08_2_02 { get; set; }
        [JsonPropertyName("hibf9_2")]
        public string CLM_HIBF09_2_02 { get; set; }
        [JsonPropertyName("hibf10_2")]
        public string CLM_HIBF10_2_02 { get; set; }
        [JsonPropertyName("hibf11_2")]
        public string CLM_HIBF11_2_02 { get; set; }
        [JsonPropertyName("hibf12_2")]
        public string CLM_HIBF12_2_02 { get; set; }
        [JsonPropertyName("hcp01")]
        public string CLM_HCP01 { get; set; }
        [JsonPropertyName("hcp02")]
        public decimal? CLM_HCP02 { get; set; }
        [JsonPropertyName("hcp03")]
        public decimal? CLM_HCP03 { get; set; }
        [JsonPropertyName("hcp04")]
        public string CLM_HCP04 { get; set; }
        [JsonPropertyName("hcp05")]
        public decimal? CLM_HCP05 { get; set; }
        [JsonPropertyName("hcp06")]
        public string CLM_HCP06 { get; set; }
        [JsonPropertyName("hcp07")]
        public decimal? CLM_HCP07 { get; set; }
        [JsonPropertyName("hcp08")]
        public string CLM_HCP08 { get; set; }
        [JsonPropertyName("hcp09")]
        public string CLM_HCP09 { get; set; }
        [JsonPropertyName("hcp10")]
        public string CLM_HCP10 { get; set; }
        [JsonPropertyName("hcp11")]
        public string CLM_HCP11 { get; set; }
        [JsonPropertyName("hcp12")]
        public decimal? CLM_HCP12 { get; set; }
        [JsonPropertyName("hcp13")]
        public string CLM_HCP13 { get; set; }
        [JsonPropertyName("hcp14")]
        public string CLM_HCP14 { get; set; }
        [JsonPropertyName("hcp15")]
        public string CLM_HCP15 { get; set; }
        [JsonIgnore]
        public decimal? CLM_ORTHO_MONTHS_CNT { get; set; }
        [JsonIgnore]
        public string CLM_ORTHO_DEVICE_IND { get; set; }
        [JsonIgnore]
        public string CLM_ST03_IG_VERSION { get; set; }
        [JsonPropertyName("reprc_rcv_dt")]
        public DateTime? CLM_REPRICE_RCV_DT { get; set; }
        [JsonIgnore]
        public string CLM_DIAG12 { get; set; }
        [JsonIgnore]
        public decimal? CLM_D_COB_PAYER_PD_AMT { get; set; }
        [JsonIgnore]
        public decimal? CLM_EAF_REMAIN_PAT_LIABILITY { get; set; }
        [JsonIgnore]
        public decimal? CLM_A8_COB_NONCOVERED_CHRGS { get; set; }
        [JsonPropertyName("bht03")]
        public string CLM_BHT03 { get; set; }
        [JsonPropertyName("ndb_mpin_cd")]
        public string CLM_NDB_MPIN_CD { get; set; }
        [JsonIgnore]
        public string CLM_NDB_SUFFIX_CD { get; set; }
        [JsonPropertyName("bht06")]
        public string CLM_BHT06 { get; set; }
        [JsonPropertyName("rmk_3")]
        public string CLM_MOA03_PYMTRMKCD { get; set; }
        [JsonPropertyName("rmk_4")]
        public string CLM_MOA04_PYMTRMKCD { get; set; }
        [JsonPropertyName("rmk_5")]
        public string CLM_MOA05_PYMTRMKCD { get; set; }
        [JsonPropertyName("rmk_6")]
        public string CLM_MOA06_PYMTRMKCD { get; set; }
        [JsonPropertyName("rmk_7")]
        public string CLM_MOA07_PYMTRMKCD { get; set; }
    }
}

﻿using System.Text.Json.Serialization;

namespace Doc360Payload.Payload
{
    /// <summary>
    /// EDI_PRV_ROUTE
    /// </summary>
    public class Provider
    {
        [JsonIgnore]
        public string PRV_REC_TYPE { get; set; }
        [JsonIgnore]
        public string PRV_BATCH_NUMBER { get; set; }
        [JsonPropertyName("sub_id")]
        public string PRV_SUB_ID { get; set; }
        [JsonPropertyName("prov_cd")]
        public string PRV_PROV_CODE { get; set; }
        [JsonPropertyName("tin_cd")]
        public string PRV_TIN_CODE { get; set; }
        [JsonPropertyName("tax_id")]
        public string PRV_TAX_ID { get; set; }
        [JsonPropertyName("ssn")]
        public string PRV_SSN { get; set; }
        [JsonIgnore]
        public string PRV_ID_PRE { get; set; }
        [JsonIgnore]
        public string PRV_ID_SUF { get; set; }
        [JsonIgnore]
        public string PRV_AGY_CODE { get; set; }
        [JsonPropertyName("specialty")]
        public string PRV_SPECIALTY { get; set; }
        [JsonIgnore]
        public string PRV_ORG_TYPE { get; set; }
        [JsonIgnore]
        public string PRV_ORG_ENT { get; set; }
        [JsonIgnore]
        public string PRV_ORG_QUAL { get; set; }
        [JsonIgnore]
        public string PRV_ORG_NAME { get; set; }
        [JsonIgnore]
        public string PRV_ORG_PH_IND { get; set; }
        [JsonIgnore]
        public string PRV_ORG_TE_IND { get; set; }
        [JsonIgnore]
        public decimal? PRV_ORG_AREA_CODE { get; set; }
        [JsonIgnore]
        public decimal? PRV_ORG_PHONE1 { get; set; }
        [JsonIgnore]
        public decimal? PRV_ORG_PHONE2 { get; set; }
        [JsonIgnore]
        public string PRV_IND_ENT { get; set; }
        [JsonIgnore]
        public string PRV_IND_QUAL { get; set; }
        [JsonPropertyName("name_last")]
        public string PRV_NAME_LAST { get; set; }
        [JsonPropertyName("name_first")]
        public string PRV_NAME_FIRST { get; set; }
        [JsonIgnore]
        public string PRV_NAME_MID { get; set; }
        [JsonIgnore]
        public string PRV_IND_NAME { get; set; }
        [JsonPropertyName("addr1")]
        public string PRV_ADDRESS_1 { get; set; }
        [JsonPropertyName("addr2")]
        public string PRV_ADDRESS_2 { get; set; }
        [JsonPropertyName("city")]
        public string PRV_CITY { get; set; }
        [JsonPropertyName("state")]
        public string PRV_STATE { get; set; }
        [JsonPropertyName("zip")]
        public string PRV_ZIP { get; set; }
        [JsonIgnore]
        public string PRV_IND_PH_IND { get; set; }
        [JsonPropertyName("ind_te")]
        public string PRV_IND_TE_IND { get; set; }
        [JsonPropertyName("area_cd")]
        public int? PRV_AREA_CODE { get; set; }
        [JsonPropertyName("phone")]
        public int? PRV_PHONE1 { get; set; }
        [JsonPropertyName("phone2")]
        public int? PRV_PHONE2 { get; set; }
        [JsonPropertyName("ppo_ind")]
        public string PRV_PPO_IND { get; set; }
        [JsonPropertyName("ppo_id")]
        public string PRV_PPO_ID { get; set; }
        [JsonIgnore]
        public DateTime? PRV_PPO_EFF_DT { get; set; }
        [JsonIgnore]
        public string PRV_1099_RPTABLE { get; set; }
        [JsonPropertyName("rnd_addr1")]
        public string PRV_REND_ADDR1 { get; set; }
        [JsonPropertyName("rnd_addr2")]
        public string PRV_REND_ADDR2 { get; set; }
        [JsonPropertyName("rnd_city")]
        public string PRV_REND_CITY { get; set; }
        [JsonPropertyName("rnd_st")]
        public string PRV_REND_ST { get; set; }
        [JsonPropertyName("rnd_zip")]
        public string PRV_REND_ZIP { get; set; }
        [JsonIgnore]
        public string PRV_KEY_UPDATED { get; set; }
        [JsonPropertyName("rend_no")]
        public string PRV_REND_NO { get; set; }
        [JsonPropertyName("ref_last")]
        public string PRV_REF_LAST_NAME { get; set; }
        [JsonPropertyName("ref_first")]
        public string PRV_REF_FIRST_NAME { get; set; }
        [JsonPropertyName("ref_no")]
        public string PRV_REF_NO { get; set; }
        [JsonIgnore]
        public string PRV_FAX { get; set; }
        [JsonIgnore]
        public string PRV_REF_NUM1 { get; set; }
        [JsonIgnore]
        public string PRV_REF_NUM2 { get; set; }
        [JsonIgnore]
        public string PRV_REF_NUM3 { get; set; }
        [JsonPropertyName("op_nm_last")]
        public string PRV_OP_NM_LAST { get; set; }
        [JsonPropertyName("op_nm_first")]
        public string PRV_OP_NM_FIRST { get; set; }
        [JsonPropertyName("op_nm_mid")]
        public string PRV_OP_NM_MID { get; set; }
        [JsonIgnore]
        public string PRV_REND_NO2 { get; set; }
        [JsonIgnore]
        public string PRV_ORIG_DEST { get; set; }
        [JsonIgnore]
        public DateTime? PRV_ORIG_DEST_DATE { get; set; }
        [JsonIgnore]
        public string PRV_CORR_DEST { get; set; }
        [JsonIgnore]
        public DateTime? PRV_CORR_DEST_DATE { get; set; }
        [JsonIgnore]
        public string PRV_OPER_ID { get; set; }
        [JsonIgnore]
        public DateTime? PRV_OPER_DATE { get; set; }
        [JsonPropertyName("ccn")]
        public string PRV_BLX_ID { get; set; }
        [JsonIgnore]
        public string PRV_CLAIM_STATUS { get; set; }
        [JsonPropertyName("fac_name")]
        public string PRV_FAC_REND_NAME { get; set; }
        [JsonPropertyName("fac_addr1")]
        public string PRV_FAC_REND_ADDR1 { get; set; }
        [JsonPropertyName("fac_addr2")]
        public string PRV_FAC_REND_ADDR2 { get; set; }
        [JsonPropertyName("fac_city")]
        public string PRV_FAC_REND_CITY { get; set; }
        [JsonPropertyName("fac_st")]
        public string PRV_FAC_REND_ST { get; set; }
        [JsonPropertyName("fac_zip")]
        public string PRV_FAC_REND_ZIP { get; set; }
        [JsonIgnore]
        public string PRV_REF_UPIN { get; set; }
        [JsonPropertyName("rend_spec_cd")]
        public string PRV_REND_SPECIALTY_CD { get; set; }
        [JsonIgnore]
        public DateTime? PRV_REND_SIGN_DT { get; set; }
        [JsonIgnore]
        public string PRV_MEDICARE_NUM { get; set; }
        [JsonIgnore]
        public string PRV_REF_NO_IND { get; set; }
        [JsonIgnore]
        public string PRV_REF_MID_NAME { get; set; }
        [JsonIgnore]
        public string PRV_REF_PHONE { get; set; }
        [JsonIgnore]
        public string PRV_REND_SUFFIX { get; set; }
        [JsonPropertyName("bill_npi")]
        public string PRV_BILLING_NPI { get; set; }
        [JsonPropertyName("payto_npi")]
        public string PRV_PAYTO_NPI { get; set; }
        [JsonPropertyName("ref_npi")]
        public string PRV_REF_NPI { get; set; }
        [JsonPropertyName("rend_npi")]
        public string PRV_REND_NPI { get; set; }
        [JsonIgnore]
        public string PRV_FACLOC_NPI { get; set; }
        [JsonPropertyName("att_npi")]
        public string PRV_ATTEND_NPI { get; set; }
        [JsonPropertyName("oper_npi")]
        public string PRV_OPER_NPI { get; set; }
        [JsonPropertyName("oth_npi")]
        public string PRV_OTHER_NPI { get; set; }
        [JsonIgnore]
        public string PRV_BILLING_ST_LIC_NUM { get; set; }
        [JsonIgnore]
        public string PRV_BILLING_BC_PRV_NUM { get; set; }
        [JsonIgnore]
        public string PRV_BILLING_BS_PRV_NUM { get; set; }
        [JsonIgnore]
        public string PRV_BILLING_PRV_COM_NUM { get; set; }
        [JsonIgnore]
        public string PRV_PAYTO_ST_LIC_NUM { get; set; }
        [JsonIgnore]
        public string PRV_PAYTO_BC_PRV_NUM { get; set; }
        [JsonIgnore]
        public string PRV_PAYTO_BS_PRV_NUM { get; set; }
        [JsonIgnore]
        public string PRV_PAYTO_PRV_COM_NUM { get; set; }
        [JsonIgnore]
        public string PRV_REND_ST_LIC_NUM { get; set; }
        [JsonIgnore]
        public string PRV_REND_BC_PRV_NUM { get; set; }
        [JsonIgnore]
        public string PRV_REND_BS_PRV_NUM { get; set; }
        [JsonIgnore]
        public string PRV_REND_PRV_COM_NUM { get; set; }
        [JsonIgnore]
        public string PRV_NM103_82 { get; set; }
        [JsonIgnore]
        public string PRV_NM104_82 { get; set; }
        [JsonIgnore]
        public string PRV_NM105_82 { get; set; }
        [JsonIgnore]
        public string PRV_REF1G_82 { get; set; }
        [JsonIgnore]
        public string PRV_REFEI_82 { get; set; }
        [JsonIgnore]
        public string PRV_REFSY_82 { get; set; }
        [JsonPropertyName("prv1")]
        public string PRV_BLNG_PRVD_PRV01 { get; set; }
        [JsonPropertyName("prv2")]
        public string PRV_BLNG_PRVD_PRV02 { get; set; }
        [JsonPropertyName("prv3")]
        public string PRV_BLNG_PRVD_PRV03 { get; set; }
        [JsonIgnore]
        public string PRV_REFER_PRVD_PRV01 { get; set; }
        [JsonIgnore]
        public string PRV_REFER_PRVD_PRV02 { get; set; }
        [JsonIgnore]
        public string PRV_REFER_PRVD_PRV03 { get; set; }
        [JsonIgnore]
        public string PRV_ATTEND_PRVD_PRV01 { get; set; }
        [JsonIgnore]
        public string PRV_ATTEND_PRVD_PRV02 { get; set; }
        [JsonIgnore]
        public string PRV_ATTEND_PRVD_PRV03 { get; set; }
        [JsonIgnore]
        public string PRV_REND_PRVD_PRV01 { get; set; }
        [JsonIgnore]
        public string PRV_REND_PRVD_PRV02 { get; set; }
        [JsonIgnore]
        public string PRV_REND_PRVD_PRV03 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER01 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER02 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER03 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER04 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER05 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER06 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER07 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER08 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER01_02 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER02_02 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER03_02 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER04_02 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER05_02 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER06_02 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER07_02 { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_PER08_02 { get; set; }
        [JsonIgnore]
        public string PRV_REJ_RSN_CD { get; set; }
        [JsonPropertyName("bp_qual")]
        public string PRV_BLNG_PRVD_QUAL { get; set; }
        [JsonPropertyName("bp_name1")]
        public string PRV_BLNG_PRVD_NAME_LAST { get; set; }
        [JsonPropertyName("bp_name2")]
        public string PRV_BLNG_PRVD_NAME_FIRST { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_NAME_MID { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_NAME_SUFF { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_ID_QUAL { get; set; }
        [JsonPropertyName("bp_npi")]
        public string PRV_BLNG_PRVD_NPI { get; set; }
        [JsonPropertyName("bp_tin")]
        public string PRV_BLNG_PRVD_TIN { get; set; }
        [JsonPropertyName("bp_addr1")]
        public string PRV_BLNG_PRVD_ADDR1 { get; set; }
        [JsonPropertyName("bp_addr2")]
        public string PRV_BLNG_PRVD_ADDR2 { get; set; }
        [JsonPropertyName("bp_city")]
        public string PRV_BLNG_PRVD_CITY { get; set; }
        [JsonPropertyName("bp_st")]
        public string PRV_BLNG_PRVD_STATE { get; set; }
        [JsonPropertyName("bp_zip")]
        public string PRV_BLNG_PRVD_ZIP { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_CNTRY { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_CNTRY_SUB { get; set; }
        [JsonPropertyName("pt_qual")]
        public string PRV_PAY_TO_PRVD_QUAL { get; set; }
        [JsonPropertyName("pt_name1")]
        public string PRV_PAY_TO_PRVD_NAME_LAST { get; set; }
        [JsonPropertyName("pt_name2")]
        public string PRV_PAY_TO_PRVD_NAME_FIRST { get; set; }
        [JsonIgnore]
        public string PRV_PAY_TO_PRVD_NAME_MID { get; set; }
        [JsonIgnore]
        public string PRV_PAY_TO_PRVD_NAME_SUFF { get; set; }
        [JsonPropertyName("pt_id_qual")]
        public string PRV_PAY_TO_PRVD_ID_QUAL { get; set; }
        [JsonPropertyName("pt_npi")]
        public string PRV_PAY_TO_PRVD_NPI { get; set; }
        [JsonPropertyName("pt_tin")]
        public string PRV_PAY_TO_PRVD_TIN { get; set; }
        [JsonPropertyName("pt_addr1")]
        public string PRV_PAY_TO_PRVD_ADDR1 { get; set; }
        [JsonPropertyName("pt_addr2")]
        public string PRV_PAY_TO_PRVD_ADDR2 { get; set; }
        [JsonPropertyName("pt_city")]
        public string PRV_PAY_TO_PRVD_CITY { get; set; }
        [JsonPropertyName("pt_st")]
        public string PRV_PAY_TO_PRVD_STATE { get; set; }
        [JsonPropertyName("pt_zip")]
        public string PRV_PAY_TO_PRVD_ZIP { get; set; }
        [JsonPropertyName("pt_cntry")]
        public string PRV_PAY_TO_PRVD_CNTRY { get; set; }
        [JsonIgnore]
        public string PRV_PAY_TO_PRVD_CNTRY_SUB { get; set; }
        [JsonIgnore]
        public string PRV_ATTEND_PHYS_QUAL { get; set; }
        [JsonIgnore]
        public string PRV_ATTEND_PHYS_NAME_LAST { get; set; }
        [JsonIgnore]
        public string PRV_ATTEND_PHYS_NAME_FIRST { get; set; }
        [JsonIgnore]
        public string PRV_ATTEND_PHYS_NAME_MID { get; set; }
        [JsonIgnore]
        public string PRV_ATTEND_PHYS_NAME_SUFF { get; set; }
        [JsonIgnore]
        public string PRV_ATTEND_PHYS_ID_QUAL { get; set; }
        [JsonIgnore]
        public string PRV_ATTEND_PHYS_NPI { get; set; }
        [JsonIgnore]
        public string PRV_ATTEND_PHYS_TIN { get; set; }
        [JsonIgnore]
        public string PRV_BLNG_PRVD_UPIN { get; set; }
        [JsonIgnore]
        public string PRV_REF_NAME_SUFF { get; set; }
        [JsonIgnore]
        public string PRV_OPER_PRVD_NAME_LAST { get; set; }
        [JsonIgnore]
        public string PRV_OPER_PRVD_NAME_FIRST { get; set; }
        [JsonIgnore]
        public string PRV_OPER_PRVD_NAME_MID { get; set; }
        [JsonIgnore]
        public string PRV_OPER_PRVD_NAME_SUFF { get; set; }
        [JsonIgnore]
        public string PRV_OP_NM_SUFF { get; set; }
        [JsonIgnore]
        public string PRV_FAC_REND_CNTRY { get; set; }
        [JsonIgnore]
        public string PRV_FAC_REND_CNTRY_SUB { get; set; }
        [JsonPropertyName("pt_plan_name")]
        public string PRV_PAY_TO_PLAN_NAME { get; set; }
        [JsonPropertyName("pt_plan_qual")]
        public string PRV_PAY_TO_PLAN_QUAL { get; set; }
        [JsonPropertyName("pt_plan_id")]
        public string PRV_PAY_TO_PLAN_ID { get; set; }
        [JsonPropertyName("pt_plan_addr1")]
        public string PRV_PAY_TO_PLAN_ADDR1 { get; set; }
        [JsonPropertyName("pt_plan_addr2")]
        public string PRV_PAY_TO_PLAN_ADDR2 { get; set; }
        [JsonPropertyName("pt_plan_city")]
        public string PRV_PAY_TO_PLAN_CITY { get; set; }
        [JsonPropertyName("pt_plan_st")]
        public string PRV_PAY_TO_PLAN_ST { get; set; }
        [JsonPropertyName("pt_plan_zip")]
        public string PRV_PAY_TO_PLAN_ZIP { get; set; }
        [JsonPropertyName("pt_plan_ctry")]
        public string PRV_PAY_TO_PLAN_CTRY { get; set; }
        [JsonIgnore]
        public string PRV_PAY_TO_PLAN_CTRY_SUB { get; set; }
        [JsonPropertyName("pt_plan_tin")]
        public string PRV_PAY_TO_PLAN_TIN { get; set; }
        [JsonIgnore]
        public string PRV_AMB_PU_ADDR1 { get; set; }
        [JsonIgnore]
        public string PRV_AMB_PU_ADDR2 { get; set; }
        [JsonIgnore]
        public string PRV_AMB_PU_CITY { get; set; }
        [JsonIgnore]
        public string PRV_AMB_PU_ST { get; set; }
        [JsonIgnore]
        public string PRV_AMB_PU_ZIP { get; set; }
        [JsonIgnore]
        public string PRV_AMB_PU_CTRY { get; set; }
        [JsonIgnore]
        public string PRV_AMB_PU_CTRY_SUB { get; set; }
    }
}

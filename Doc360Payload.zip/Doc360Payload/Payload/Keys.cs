﻿using System.Text.Json.Serialization;

namespace Doc360Payload.Payload
{
    public class Keys
    {
        /// <summary>
        /// TRANS TYPE / DOCUMENT TYPE
        /// </summary>
        [JsonPropertyName("doc")]
        public string DocumentType { get; set; }
        /// <summary>
        /// CPS CLAIM CONTROL NUMBER
        /// </summary>
        [JsonPropertyName("ccn")]
        public string CCN { get; set; }
        /// <summary>
        /// BIDS/BATCH NUMBER
        /// </summary>
        [JsonPropertyName("bids")]
        public string BIDS { get; set; }
        /// <summary>
        /// UMR EDI ID
        /// </summary>
        [JsonPropertyName("umr_id")]
        public string UMREDIID { get; set; }
        /// <summary>
        /// DOC360 WORK QUEUE ID
        /// </summary>
        [JsonPropertyName("wq_id")]
        public long WorkQueueId { get; set; }
    }
}

﻿using System.Text.Json.Serialization;

namespace Doc360Payload.Payload
{
    /// <summary>
    /// EDI_PAT_ROUTE
    /// </summary>
    public class Patient
    {
        [JsonIgnore]
        public string PAT_REC_TYPE { get; set; }
        [JsonIgnore]
        public string PAT_BATCH_NUM { get; set; }
        [JsonPropertyName("pay_rsp_cd")]
        public string PAT_PAY_RESP_CODE { get; set; }
        [JsonPropertyName("grp_name")]
        public string PAT_GROUP_NAME { get; set; }
        [JsonIgnore]
        public string PAT_INS_TYPE { get; set; }
        [JsonIgnore]
        public string PAT_EMP_STATUS { get; set; }
        [JsonPropertyName("sbr_cd")]
        public string PAT_SBR_CODE { get; set; }
        [JsonPropertyName("sbr_ent")]
        public string PAT_SBR_ENT { get; set; }
        [JsonPropertyName("sbr_last")]
        public string PAT_SBR_LAST { get; set; }
        [JsonPropertyName("sbr_first")]
        public string PAT_SBR_FIRST { get; set; }
        [JsonPropertyName("sbr_mid")]
        public string PAT_SBR_MID { get; set; }
        [JsonIgnore]
        public string PAT_SBR_GEN { get; set; }
        [JsonIgnore]
        public string PAT_SBR_NAME { get; set; }
        [JsonPropertyName("sbr_addr1")]
        public string PAT_SBR_ADDR1 { get; set; }
        [JsonPropertyName("sbr_addr2")]
        public string PAT_SBR_ADDR2 { get; set; }
        [JsonPropertyName("sbr_city")]
        public string PAT_SBR_CITY { get; set; }
        [JsonPropertyName("sbr_st")]
        public string PAT_SBR_ST { get; set; }
        [JsonPropertyName("sbr_zip")]
        public string PAT_SBR_ZIP { get; set; }
        [JsonIgnore]
        public string PAT_SBR_DOB_FORM { get; set; }
        [JsonPropertyName("sbr_dob")]
        public DateTime? PAT_SBR_DOB { get; set; }
        [JsonPropertyName("sbr_sex")]
        public string PAT_SBR_SEX { get; set; }
        [JsonPropertyName("pat_id_typ")]
        public string PAT_ID_TYPE { get; set; }
        [JsonPropertyName("pat_id")]
        public string PAT_ID { get; set; }
        [JsonPropertyName("sbr_rel")]
        public string PAT_SBR_REL { get; set; }
        [JsonIgnore]
        public string PAT_RES_TYPE { get; set; }
        [JsonIgnore]
        public string PAT_SUB_TYPE { get; set; }
        [JsonIgnore]
        public string PAT_ENT_IND { get; set; }
        [JsonPropertyName("name_last")]
        public string PAT_NAME_LAST { get; set; }
        [JsonPropertyName("name_first")]
        public string PAT_NAME_FIRST { get; set; }
        [JsonPropertyName("name_mid")]
        public string PAT_NAME_MID { get; set; }
        [JsonIgnore]
        public string PAT_NAME_GEN { get; set; }
        [JsonIgnore]
        public string PAT_NAME { get; set; }
        [JsonPropertyName("addr1")]
        public string PAT_ADDR1 { get; set; }
        [JsonPropertyName("addr2")]
        public string PAT_ADDR2 { get; set; }
        [JsonPropertyName("city")]
        public string PAT_CITY { get; set; }
        [JsonPropertyName("st")]
        public string PAT_ST { get; set; }
        [JsonPropertyName("zip")]
        public string PAT_ZIP { get; set; }
        [JsonIgnore]
        public string PAT_DOB_FORM { get; set; }
        [JsonPropertyName("dob")]
        public DateTime? PAT_DOB { get; set; }
        [JsonPropertyName("sex")]
        public string PAT_SEX { get; set; }
        [JsonIgnore]
        public string PAT_PZ_IND { get; set; }
        [JsonIgnore]
        public string PAT_TE_IND { get; set; }
        [JsonIgnore]
        public string PAT_PHONE { get; set; }
        [JsonIgnore]
        public string PAT_ID_IND { get; set; }
        [JsonPropertyName("ssn")]
        public string PAT_SSN { get; set; }
        [JsonIgnore]
        public string PAT_KEY_UPDATED { get; set; }
        [JsonIgnore]
        public string PAT_EMPL_NAME { get; set; }
        [JsonPropertyName("carr_id")]
        public string PAT_CARRIER_ID { get; set; }
        [JsonPropertyName("hic_no")]
        public string PAT_HIC_NUMBER { get; set; }
        [JsonPropertyName("cob_ind")]
        public string PAT_COB_IND { get; set; }
        [JsonIgnore]
        public DateTime? PAT_DOD { get; set; }
        [JsonIgnore]
        public string PAT_MTL_STS { get; set; }
        [JsonPropertyName("ref_num")]
        public string PAT_REF_NUM { get; set; }
        [JsonPropertyName("sbr_phone")]
        public string PAT_SBR_PHONE { get; set; }
        [JsonPropertyName("lglr_naml")]
        public string PAT_LGLR_NAML { get; set; }
        [JsonPropertyName("lglr_namf")]
        public string PAT_LGLR_NAMF { get; set; }
        [JsonPropertyName("lglr_namm")]
        public string PAT_LGLR_NAMM { get; set; }
        [JsonPropertyName("lglr_city")]
        public string PAT_LGLR_CITY { get; set; }
        [JsonPropertyName("lglr_addr1")]
        public string PAT_LGLR_ADDR1 { get; set; }
        [JsonPropertyName("lglr_st")]
        public string PAT_LGLR_ST { get; set; }
        [JsonPropertyName("lglr_zip")]
        public string PAT_LGLR_ZIP { get; set; }
        [JsonPropertyName("lglrphn")]
        public string PAT_LGLRPHN { get; set; }
        [JsonPropertyName("payor_name")]
        public string PAT_SBR_PAYOR_NAME { get; set; }
        [JsonPropertyName("sbr_org")]
        public string PAT_SBR_ORGNM1 { get; set; }
        [JsonIgnore]
        public string PAT_SBR_ORG_ADR1 { get; set; }
        [JsonIgnore]
        public string PAT_SBR_ORG_CITY { get; set; }
        [JsonIgnore]
        public string PAT_SBR_ORG_ST { get; set; }
        [JsonIgnore]
        public string PAT_SBR_ORG_ZIP { get; set; }
        [JsonIgnore]
        public string PAT_FILE_CREATE_DT { get; set; }
        [JsonPropertyName("tp_id")]
        public decimal PAT_TP_ID { get; set; }
        [JsonIgnore]
        public string PAT_FILE_CREATE_TM { get; set; }
        [JsonIgnore]
        public string PAT_STUDENT_STS { get; set; }
        [JsonIgnore]
        public string PAT_AUTH_RELEASE_IND { get; set; }
        [JsonPropertyName("mbr_id")]
        public string PAT_MEMBER_ID { get; set; }
        [JsonIgnore]
        public decimal? PAT_SEQ_NO { get; set; }
        [JsonPropertyName("pay_rsp_cd1")]
        public string PAT_OTH_SBR_PAY_RESP_CODE1 { get; set; }
        [JsonPropertyName("pay_rsp_cd2")]
        public string PAT_OTH_SBR_PAY_RESP_CODE2 { get; set; }
        [JsonPropertyName("pay_rsp_cd3")]
        public string PAT_OTH_SBR_PAY_RESP_CODE3 { get; set; }
        [JsonPropertyName("pay_rsp_cd4")]
        public string PAT_OTH_SBR_PAY_RESP_CODE4 { get; set; }
        [JsonPropertyName("pay_rsp_cd5")]
        public string PAT_OTH_SBR_PAY_RESP_CODE5 { get; set; }
        [JsonPropertyName("pay_rsp_cd6")]
        public string PAT_OTH_SBR_PAY_RESP_CODE6 { get; set; }
        [JsonPropertyName("pay_rsp_cd7")]
        public string PAT_OTH_SBR_PAY_RESP_CODE7 { get; set; }
        [JsonPropertyName("pay_rsp_cd8")]
        public string PAT_OTH_SBR_PAY_RESP_CODE8 { get; set; }
        [JsonPropertyName("pay_rsp_cd9")]
        public string PAT_OTH_SBR_PAY_RESP_CODE9 { get; set; }
        [JsonPropertyName("pay_rsp_cd10")]
        public string PAT_OTH_SBR_PAY_RESP_CODE10 { get; set; }
        [JsonPropertyName("oth_ins1")]
        public string PAT_OTH_SBR_INS_TYPE1 { get; set; }
        [JsonPropertyName("oth_ins2")]
        public string PAT_OTH_SBR_INS_TYPE2 { get; set; }
        [JsonPropertyName("oth_ins3")]
        public string PAT_OTH_SBR_INS_TYPE3 { get; set; }
        [JsonPropertyName("oth_ins4")]
        public string PAT_OTH_SBR_INS_TYPE4 { get; set; }
        [JsonPropertyName("oth_ins5")]
        public string PAT_OTH_SBR_INS_TYPE5 { get; set; }
        [JsonPropertyName("oth_ins6")]
        public string PAT_OTH_SBR_INS_TYPE6 { get; set; }
        [JsonPropertyName("oth_ins7")]
        public string PAT_OTH_SBR_INS_TYPE7 { get; set; }
        [JsonPropertyName("oth_ins8")]
        public string PAT_OTH_SBR_INS_TYPE8 { get; set; }
        [JsonPropertyName("oth_ins9")]
        public string PAT_OTH_SBR_INS_TYPE9 { get; set; }
        [JsonPropertyName("oth_ins10")]
        public string PAT_OTH_SBR_INS_TYPE10 { get; set; }
        [JsonIgnore]
        public string PAT_OTH_SBR_INS_FILING_IND1 { get; set; }
        [JsonIgnore]
        public string PAT_OTH_SBR_INS_FILING_IND2 { get; set; }
        [JsonIgnore]
        public string PAT_OTH_SBR_INS_FILING_IND3 { get; set; }
        [JsonIgnore]
        public string PAT_OTH_SBR_INS_FILING_IND4 { get; set; }
        [JsonIgnore]
        public string PAT_OTH_SBR_INS_FILING_IND5 { get; set; }
        [JsonIgnore]
        public string PAT_OTH_SBR_INS_FILING_IND6 { get; set; }
        [JsonIgnore]
        public string PAT_OTH_SBR_INS_FILING_IND7 { get; set; }
        [JsonIgnore]
        public string PAT_OTH_SBR_INS_FILING_IND8 { get; set; }
        [JsonIgnore]
        public string PAT_OTH_SBR_INS_FILING_IND9 { get; set; }
        [JsonIgnore]
        public string PAT_OTH_SBR_INS_FILING_IND10 { get; set; }
        [JsonIgnore]
        public string PAT_SBR_CNTRY { get; set; }
        [JsonIgnore]
        public string PAT_SBR_CNTRY_SUB { get; set; }
        [JsonIgnore]
        public string PAT_CNTRY { get; set; }
        [JsonIgnore]
        public string PAT_CNTRY_SUB { get; set; }
    }
}

﻿using System.Text.Json.Serialization;

namespace Doc360Payload.Payload
{
    /// <summary>
    /// EDI_SVC_ROUTE
    /// </summary>
    public class ServiceLine
    {
        [JsonIgnore]
        public string SVC_REC_TYPE { get; set; }
        [JsonIgnore]
        public string SVC_BATCH_NUM { get; set; }
        [JsonIgnore]
        public decimal? SVC_POLICY { get; set; }
        [JsonIgnore]
        public string SVC_CERT { get; set; }
        [JsonPropertyName("ln_no")]
        public string SVC_LINE_NUM { get; set; }
        [JsonPropertyName("hcpcs_tbl")]
        public string SVC_HCPCS_TABLE { get; set; }
        [JsonPropertyName("hcpcs_cd")]
        public string SVC_HCPCS_CODE { get; set; }
        [JsonPropertyName("ln_chgs")]
        public decimal? SVC_LINE_CHGS { get; set; }
        [JsonPropertyName("not_cov_amt")]
        public decimal? SVC_NOT_COVERED_AMT { get; set; }
        [JsonPropertyName("units_ind")]
        public string SVC_UNIT_IND { get; set; }
        [JsonPropertyName("units")]
        public decimal? SVC_UNITS { get; set; }
        [JsonPropertyName("place")]
        public string SVC_PLACE { get; set; }
        [JsonPropertyName("type")]
        public string SVC_TYPE { get; set; }
        [JsonPropertyName("diag_ptr1")]
        public string SVC_DIAG_PTR_1 { get; set; }
        [JsonPropertyName("hcpcs_mod")]
        public string SVC_HCPCS_MOD { get; set; }
        [JsonPropertyName("diag_ptr2")]
        public string SVC_DIAG_PTR_2 { get; set; }
        [JsonPropertyName("emg_ind")]
        public string SVC_EMER_IND { get; set; }
        [JsonPropertyName("cob_ind")]
        public string SVC_COB_IND { get; set; }
        [JsonPropertyName("diag_ind")]
        public string SVC_DIAG_IND { get; set; }
        [JsonIgnore]
        public string SVC_DIAG_TABLE { get; set; }
        [JsonPropertyName("diag_ptr3")]
        public string SVC_DIAG_PTR_3 { get; set; }
        [JsonPropertyName("diag_ptr4")]
        public string SVC_DIAG_PTR_4 { get; set; }
        [JsonPropertyName("serv_ind")]
        public string SVC_SERVICE_IND { get; set; }
        [JsonIgnore]
        public string SVC_RANGE_IND { get; set; }
        [JsonPropertyName("dt_frm")]
        public DateTime? SVC_DATE_FROM { get; set; }
        [JsonPropertyName("dt_to")]
        public DateTime? SVC_DATE_THRU { get; set; }
        [JsonPropertyName("ln_ind")]
        public string SVC_LINE_IND { get; set; }
        [JsonPropertyName("ln_ctrl_no")]
        public string SVC_LINE_CTRL_NUM { get; set; }
        [JsonPropertyName("prov_ind")]
        public decimal? SVC_PROV_IND { get; set; }
        [JsonPropertyName("ent_ind")]
        public decimal? SVC_ENT_IND { get; set; }
        [JsonPropertyName("medi_ind")]
        public string SVC_MEDICARE_IND { get; set; }
        [JsonPropertyName("medi_num")]
        public string SVC_MEDICARE_NUM { get; set; }
        [JsonPropertyName("tth")]
        public string SVC_TOOTH { get; set; }
        [JsonPropertyName("tth_srf")]
        public string SVC_SURFACE { get; set; }
        [JsonPropertyName("rev_cd")]
        public string SVC_REV_CODE { get; set; }
        [JsonIgnore]
        public string SVC_FILLER { get; set; }
        [JsonIgnore]
        public decimal? SVC_MED_ALLW { get; set; }
        [JsonPropertyName("med_pmt")]
        public decimal? SVC_MED_PYMT { get; set; }
        [JsonPropertyName("pat_rsp")]
        public decimal? SVC_PAT_RESP { get; set; }
        [JsonIgnore]
        public decimal? SVC_DED_APPL { get; set; }
        [JsonPropertyName("coins_amt")]
        public decimal? SVC_COINS_AMT { get; set; }
        [JsonIgnore]
        public string SVC_DED_RC { get; set; }
        [JsonPropertyName("ded_amt")]
        public decimal? SVC_DED_AMT { get; set; }
        [JsonIgnore]
        public decimal? SVC_APPR_PSY { get; set; }
        [JsonIgnore]
        public string SVC_PAY_TIND { get; set; }
        [JsonPropertyName("pre_prcd_amt")]
        public decimal? SVC_PRE_PRICED_AMT { get; set; }
        [JsonIgnore]
        public string SVC_REN_PROV_NAME { get; set; }
        [JsonPropertyName("hcpcs_rate")]
        public decimal? SVC_HCPCS_RATE { get; set; }
        [JsonPropertyName("lab_chrg")]
        public decimal? SVC_LAB_CHARGES { get; set; }
        [JsonIgnore]
        public string SVC_PRE_PRICED_REF_NO { get; set; }
        [JsonIgnore]
        public string SVC_PRE_PRICED_SUB_ID { get; set; }
        [JsonIgnore]
        public decimal? SVC_DISALLW_OTH { get; set; }
        [JsonIgnore]
        public decimal? SVC_BILL_LIMIT_CHRG { get; set; }
        [JsonIgnore]
        public decimal? SVC_LIMIT_CHRG_PRCNT { get; set; }
        [JsonPropertyName("tth_cd")]
        public string SVC_TOOTH_CD { get; set; }
        [JsonPropertyName("tth_surf1")]
        public string SVC_TOOTH_SURF_CD { get; set; }
        [JsonPropertyName("tth_surf2")]
        public string SVC_TOOTH_SURF_CD2 { get; set; }
        [JsonPropertyName("tth_surf3")]
        public string SVC_TOOTH_SURF_CD3 { get; set; }
        [JsonPropertyName("tth_surf4")]
        public string SVC_TOOTH_SURF_CD4 { get; set; }
        [JsonPropertyName("tth_surf5")]
        public string SVC_TOOTH_SURF_CD5 { get; set; }
        [JsonPropertyName("message")]
        public string SVC_MESSAGE { get; set; }
        [JsonPropertyName("rend_npi")]
        public string SVC_REND_NPI { get; set; }
        [JsonIgnore]
        public string SVC_FACLOC_NPI { get; set; }
        [JsonPropertyName("ref_npi")]
        public string SVC_REF_NPI { get; set; }
        [JsonPropertyName("natl_drug_cd")]
        public string SVC_NATL_DRUG_CD { get; set; }
        [JsonIgnore]
        public string SVC_ATTEND_NPI { get; set; }
        [JsonIgnore]
        public string SVC_OPER_NPI { get; set; }
        [JsonIgnore]
        public string SVC_OTHER_NPI { get; set; }
        [JsonIgnore]
        public string SVC_REND_ST_LIC_NUM { get; set; }
        [JsonIgnore]
        public string SVC_REND_BC_PRV_NUM { get; set; }
        [JsonIgnore]
        public string SVC_REND_BS_PRV_NUM { get; set; }
        [JsonIgnore]
        public string SVC_REND_PRV_COM_NUM { get; set; }
        [JsonIgnore]
        public string SVC_ICES_REMARK_CD { get; set; }
        [JsonIgnore]
        public string SVC_ICES_APPLIED_FLAG { get; set; }
        [JsonIgnore]
        public string SVC_LINE_DISP_CD { get; set; }
        [JsonPropertyName("ntw_cd")]
        public string SVC_NETWORK_CD { get; set; }
        [JsonPropertyName("unit_exp")]
        public decimal? SVC_UNIT_EXP { get; set; }
        [JsonPropertyName("pwk1_1")]
        public string SVC_PWK01_01 { get; set; }
        [JsonPropertyName("pwk2_1")]
        public string SVC_PWK02_01 { get; set; }
        [JsonPropertyName("pwk5_1")]
        public string SVC_PWK05_01 { get; set; }
        [JsonPropertyName("pwk6_1")]
        public string SVC_PWK06_01 { get; set; }
        [JsonPropertyName("pwk1_2")]
        public string SVC_PWK01_02 { get; set; }
        [JsonPropertyName("pwk2_2")]
        public string SVC_PWK02_02 { get; set; }
        [JsonPropertyName("pwk5_2")]
        public string SVC_PWK05_02 { get; set; }
        [JsonPropertyName("pwk6_2")]
        public string SVC_PWK06_02 { get; set; }
        [JsonPropertyName("pwk1_3")]
        public string SVC_PWK01_03 { get; set; }
        [JsonPropertyName("pwk2_3")]
        public string SVC_PWK02_03 { get; set; }
        [JsonPropertyName("pwk5_3")]
        public string SVC_PWK05_03 { get; set; }
        [JsonPropertyName("pwk6_3")]
        public string SVC_PWK06_03 { get; set; }
        [JsonPropertyName("pwk1_4")]
        public string SVC_PWK01_04 { get; set; }
        [JsonPropertyName("pwk2_4")]
        public string SVC_PWK02_04 { get; set; }
        [JsonPropertyName("pwk5_4")]
        public string SVC_PWK05_04 { get; set; }
        [JsonPropertyName("pwk6_4")]
        public string SVC_PWK06_04 { get; set; }
        [JsonPropertyName("pwk1_5")]
        public string SVC_PWK01_05 { get; set; }
        [JsonPropertyName("pwk2_5")]
        public string SVC_PWK02_05 { get; set; }
        [JsonPropertyName("pwk5_5")]
        public string SVC_PWK05_05 { get; set; }
        [JsonPropertyName("pwk6_5")]
        public string SVC_PWK06_05 { get; set; }
        [JsonPropertyName("nte1")]
        public string SVC_NTE01 { get; set; }
        [JsonPropertyName("nte2")]
        public string SVC_NTE02 { get; set; }
        [JsonPropertyName("hcp01")]
        public string SVC_HCP01 { get; set; }
        [JsonPropertyName("hcp02")]
        public decimal? SVC_HCP02 { get; set; }
        [JsonPropertyName("hcp03")]
        public decimal? SVC_HCP03 { get; set; }
        [JsonPropertyName("hcp04")]
        public string SVC_HCP04 { get; set; }
        [JsonPropertyName("hcp05")]
        public decimal? SVC_HCP05 { get; set; }
        [JsonPropertyName("hcp06")]
        public string SVC_HCP06 { get; set; }
        [JsonPropertyName("hcp07")]
        public decimal? SVC_HCP07 { get; set; }
        [JsonPropertyName("hcp08")]
        public string SVC_HCP08 { get; set; }
        [JsonPropertyName("hcp09")]
        public string SVC_HCP09 { get; set; }
        [JsonPropertyName("hcp10")]
        public string SVC_HCP10 { get; set; }
        [JsonPropertyName("hcp11")]
        public string SVC_HCP11 { get; set; }
        [JsonPropertyName("hcp12")]
        public decimal? SVC_HCP12 { get; set; }
        [JsonPropertyName("hcp13")]
        public string SVC_HCP13 { get; set; }
        [JsonPropertyName("hcp14")]
        public string SVC_HCP14 { get; set; }
        [JsonPropertyName("hcp15")]
        public string SVC_HCP15 { get; set; }
        [JsonPropertyName("svd05")]
        public decimal? SVC_SVD05 { get; set; }
        [JsonPropertyName("hcpcs_mod2")]
        public string SVC_HCPCS_MOD2 { get; set; }
        [JsonPropertyName("hcpcs_mod3")]
        public string SVC_HCPCS_MOD3 { get; set; }
        [JsonPropertyName("hcpcs_mod4")]
        public string SVC_HCPCS_MOD4 { get; set; }
        [JsonPropertyName("prv01")]
        public string SVC_REND_PRVD_PRV01 { get; set; }
        [JsonPropertyName("prv02")]
        public string SVC_REND_PRVD_PRV02 { get; set; }
        [JsonPropertyName("rend_tax_id")]
        public string SVC_REND_PRVD_PRV03 { get; set; }
        [JsonIgnore]
        public string SVC_ORDER_PRVD_PER01 { get; set; }
        [JsonIgnore]
        public string SVC_ORDER_PRVD_PER02 { get; set; }
        [JsonIgnore]
        public string SVC_ORDER_PRVD_PER03 { get; set; }
        [JsonIgnore]
        public string SVC_ORDER_PRVD_PER04 { get; set; }
        [JsonIgnore]
        public string SVC_ORDER_PRVD_PER05 { get; set; }
        [JsonIgnore]
        public string SVC_ORDER_PRVD_PER06 { get; set; }
        [JsonIgnore]
        public string SVC_ORDER_PRVD_PER07 { get; set; }
        [JsonIgnore]
        public string SVC_ORDER_PRVD_PER08 { get; set; }
        [JsonPropertyName("k3_1")]
        public string SVC_K301_01 { get; set; }
        [JsonPropertyName("k3_2")]
        public string SVC_K301_02 { get; set; }
        [JsonPropertyName("k3_3")]
        public string SVC_K301_03 { get; set; }
        [JsonPropertyName("k3_4")]
        public string SVC_K301_04 { get; set; }
        [JsonPropertyName("k3_5")]
        public string SVC_K301_05 { get; set; }
        [JsonPropertyName("k3_6")]
        public string SVC_K301_06 { get; set; }
        [JsonPropertyName("k3_7")]
        public string SVC_K301_07 { get; set; }
        [JsonPropertyName("k3_8")]
        public string SVC_K301_08 { get; set; }
        [JsonPropertyName("k3_9")]
        public string SVC_K301_09 { get; set; }
        [JsonPropertyName("k3_10")]
        public string SVC_K301_10 { get; set; }
        [JsonPropertyName("nte1_2")]
        public string SVC_NTE01_02 { get; set; }
        [JsonPropertyName("nte2_2")]
        public string SVC_NTE02_02 { get; set; }
        [JsonIgnore]
        public decimal? SVC_EAF_REMAIN_PAT_LIABILITY { get; set; }
        [JsonIgnore]
        public string SVC_REF_PRVD_NAME_LAST { get; set; }
        [JsonIgnore]
        public string SVC_REF_PRVD_NAME_FIRST { get; set; }
        [JsonIgnore]
        public string SVC_REF_PRVD_NAME_MID { get; set; }
        [JsonIgnore]
        public string SVC_REF_PRVD_SUFFIX { get; set; }
        [JsonIgnore]
        public string SVC_DRUG_QUANTITY { get; set; }
        [JsonIgnore]
        public string SVC_DRUG_MEASURE_CD { get; set; }
        [JsonPropertyName("svd2")]
        public decimal? SVC_SVD02 { get; set; }
        [JsonPropertyName("desc")]
        public string SVC_DESC { get; set; }
    }
}

﻿using System.Text.Json.Serialization;

namespace Doc360Payload.Payload
{
    /// <summary>
    /// EDI_CCA_ROUTE
    /// </summary>
    public class CasCodes
    {
        [JsonIgnore]
        public string CCA_REC_TYPE { get; set; }
        [JsonIgnore]
        public string CCA_BATCH_NUM { get; set; }
        [JsonPropertyName("seq_no")]
        public decimal CCA_SEQ_NO { get; set; }
        [JsonPropertyName("adj")]
        public string CCA_CAS_ADJ_GROUP_CD { get; set; }
        [JsonPropertyName("rsn")]
        public string CCA_CAS_ADJ_RSN_CD { get; set; }
        [JsonPropertyName("amt")]
        public decimal? CCA_CAS_MONETARY_AMT { get; set; }
        [JsonPropertyName("qty")]
        public decimal? CCA_CAS_QUANTITY { get; set; }
    }
}

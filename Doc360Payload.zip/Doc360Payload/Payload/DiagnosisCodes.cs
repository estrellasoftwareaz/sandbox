﻿using System.Text.Json.Serialization;

namespace Doc360Payload.Payload
{
    /// <summary>
    /// EDI_CHI_ROUTE
    /// </summary>
    public class DiagnosisCodes
    {
        [JsonIgnore]
        public string CHI_REC_TYPE { get; set; }
        [JsonIgnore]
        public string CHI_BATCH_NUM { get; set; }
        [JsonPropertyName("seq_no")]
        public int CHI_SEQ_NO { get; set; }
        [JsonPropertyName("qual_code")]
        public string CHI_HI_CD_LIST_QUAL_CD { get; set; }
        [JsonPropertyName("ind_cd")]
        public string CHI_HI_INDUSTRY_CD { get; set; }
        [JsonPropertyName("dt_tm_qual")]
        public string CHI_HI_DT_TM_FORMAT_QUAL { get; set; }
        [JsonPropertyName("dt_tm_frm")]
        public DateTime? CHI_HI_DT_TM_PERIOD_FROM { get; set; }
        [JsonPropertyName("dt_tm_thru")]
        public DateTime? CHI_HI_DT_TM_PERIOD_THRU { get; set; }
        [JsonPropertyName("mon_amt")]
        public decimal? CHI_HI_MONETARY_AMT { get; set; }
        [JsonPropertyName("resp_cde")]
        public string CHI_HI_RESPONSE_CD { get; set; }
    }
}

﻿using System.Text.Json.Serialization;

namespace Doc360Payload.Payload
{
    public class TradingPartner
    {
        [JsonPropertyName("tp_id")]
        public decimal TP_ID { get; set; }
        [JsonPropertyName("tp_name")]
        public string TP_NAME { get; set; }
        [JsonIgnore]
        public string BAL_RPT_FILE_NAME { get; set; }
        [JsonIgnore]
        public string TP_LETTER_NAME { get; set; }
        [JsonPropertyName("file_type_ind")]
        public string FILE_TYPE_IND { get; set; }
        [JsonIgnore]
        public string DEFAULT_ROUTE_ID { get; set; }
        [JsonIgnore]
        public string ELIG_BASED_ROUTING_FLAG { get; set; }
        [JsonIgnore]
        public string ELIG_BASED_MEMNO_FLAG { get; set; }
        [JsonIgnore]
        public DateTime? EXPRT_DT { get; set; }
        [JsonPropertyName("sender_id_997")]
        public string SENDER_ID_997 { get; set; }
        [JsonIgnore]
        public string ACK_RECEIVE_CD { get; set; }
        [JsonIgnore]
        public decimal? DAYS_BEFORE_OVERDUE { get; set; }
        [JsonIgnore]
        public string VENDOR_CODE { get; set; }
        [JsonIgnore]
        public string JOB_NAME { get; set; }
        [JsonIgnore]
        public string DIR_PATH { get; set; }
        [JsonIgnore]
        public string FILE_SPEC { get; set; }
        [JsonIgnore]
        public string SCRIPT_NAME { get; set; }
        [JsonIgnore]
        public string REAL_TIME { get; set; }
        [JsonPropertyName("intchg_sender_id")]
        public string INTERCHANGE_SENDER_ID { get; set; }
        [JsonIgnore]
        public string ASSIGN_CLM_NBR { get; set; }
        [JsonIgnore]
        public string CIP834 { get; set; }
    }
}

﻿namespace Doc360Payload.Payload
{
    /// <summary>
    /// Service Line Edits
    /// </summary>
    public class ServiceLineInfo
    {
    }
}

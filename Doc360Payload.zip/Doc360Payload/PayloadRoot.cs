﻿using Doc360Payload.Converters;
using Doc360Payload.Payload;
using System.Collections;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.Json.Serialization.Metadata;

namespace Doc360Payload
{
    public class PayloadRoot
    {
        /// <summary>
        /// IDENTIFIERS / KEYS
        /// </summary>
        [JsonPropertyName("keys")]
        public Keys Keys { get; set; } = new();
        /// <summary>
        /// DIAGNOSIS CODES
        /// </summary>
        [JsonPropertyName("diagnosis_codes")]
        public DiagnosisCodes[] DiagnosisCodes { get; set; } = [];
        /// <summary>
        /// CLAIM
        /// </summary>
        [JsonPropertyName("claim")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public Claim Claim { get; set; } = new();
        /// <summary>
        /// SERVICE LINES
        /// </summary>       
        [JsonPropertyName("service_lines")]
        public ServiceLine[] ServiceLines { get; set; } = [];
        /// <summary>
        /// 
        /// </summary>
        [JsonPropertyName("service_line_info")]
        public ServiceLineInfo[] ServiceLineInfos { get; set; } = [];
        /// <summary>
        /// PATIENT
        /// </summary>
        [JsonPropertyName("patient")]
        public Patient Patient { get; set; } = new();
        /// <summary>
        /// PROVIDER
        /// </summary>
        [JsonPropertyName("provider")]
        public Provider Provider { get; set; } = new();
        /// <summary>
        /// CAS CODES
        /// </summary>
        [JsonPropertyName("cas_codes")]
        public CasCodes[] CasCodes { get; set; } = [];
        /// <summary>
        /// 
        /// </summary>
        [JsonPropertyName("trade_partner")]
        public TradingPartner TradingPartner { get; set; } = new();

        /// <summary>
        /// Convert JSON to object
        /// </summary>
        /// <param name="json"></param>
        /// <returns></returns>
        public static PayloadRoot FromJson(string json) => JsonSerializer.Deserialize<PayloadRoot>(json);

        /// <summary>
        /// Convert payload object to JSON string
        /// </summary>
        /// <param name="payloadRoot"></param>
        /// <param name="indented"></param>
        /// <param name="removeEmpty"></param>
        /// <returns></returns>
        public static string ToJson(PayloadRoot payloadRoot, bool indented = false, bool removeEmpty = true)
        {
            var json = string.Empty;

            JsonSerializerOptions options = new()
            {
                DefaultIgnoreCondition = removeEmpty ? JsonIgnoreCondition.WhenWritingDefault : JsonIgnoreCondition.Never,
                WriteIndented = indented
            };

            if (removeEmpty)
                options.TypeInfoResolver = new DefaultJsonTypeInfoResolver
                {
                    Modifiers = { ExcludeEmptyAndZeroStrings }
                };

            //datetime converter
            options.Converters.Add(new CustomDateTimeConverter("yyyy-MM-dd"));

            json = JsonSerializer.Serialize(payloadRoot, options);

            return json;
        }

        /// <summary>
        /// Method to remove any empty strings, zero numbers, 
        /// and empty collections from the JSON serialization.
        /// </summary>
        /// <param name="jsonTypeInfo"></param>
        static void ExcludeEmptyAndZeroStrings(JsonTypeInfo jsonTypeInfo)
        {
            if (jsonTypeInfo.Kind != JsonTypeInfoKind.Object)
                return;

            foreach (JsonPropertyInfo jsonPropertyInfo in jsonTypeInfo.Properties)
            {
                //this is kind of dumb that i have to serialize these objects
                //to find out if they are empty                
                if (typeof(Claim).IsAssignableFrom(jsonPropertyInfo.PropertyType) ||
                    typeof(Patient).IsAssignableFrom(jsonPropertyInfo.PropertyType) ||
                    typeof(Provider).IsAssignableFrom(jsonPropertyInfo.PropertyType) ||
                    typeof(TradingPartner).IsAssignableFrom(jsonPropertyInfo.PropertyType))
                {
                    jsonPropertyInfo.ShouldSerialize = (obj, val) =>
                    {
                        var content = JsonSerializer.Serialize(val, new JsonSerializerOptions()
                        {
                            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingDefault
                        });

                        //if empty object than false, don't write
                        return content != "{}";
                    };
                }


                //remove empty collections
                if (typeof(ICollection).IsAssignableFrom(jsonPropertyInfo.PropertyType))
                {
                    jsonPropertyInfo.ShouldSerialize = (_, val) => val is ICollection collection && collection.Count > 0;
                }

                // remove empty strings
                if (jsonPropertyInfo.PropertyType == typeof(string))
                {
                    jsonPropertyInfo.ShouldSerialize = static (obj, value) =>
                        !string.IsNullOrWhiteSpace((string)value);
                }

                // remove number with 0
                if (jsonPropertyInfo.PropertyType == typeof(decimal))
                {
                    jsonPropertyInfo.ShouldSerialize = static (obj, value) => value != null && (decimal)value != 0;
                }

                // remove number with 0
                if (jsonPropertyInfo.PropertyType == typeof(decimal?))
                {
                    jsonPropertyInfo.ShouldSerialize = static (obj, value) => value != null && (decimal)value != 0;
                }

                // remove number with 0
                if (jsonPropertyInfo.PropertyType == typeof(int))
                {
                    jsonPropertyInfo.ShouldSerialize = static (obj, value) => value != null && (int)value != 0;
                }

                // remove number with 0
                if (jsonPropertyInfo.PropertyType == typeof(int?))
                {
                    jsonPropertyInfo.ShouldSerialize = static (obj, value) => value != null && (int)value != 0;
                }
            }
        }
    }
}
